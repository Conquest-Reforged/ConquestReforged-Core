package com.conquestrefabricated.content.blocks.block.overlay_top;

import com.conquestrefabricated.content.blocks.block.Slab;
import com.conquestrefabricated.core.asset.annotation.Assets;
import com.conquestrefabricated.core.asset.annotation.Model;
import com.conquestrefabricated.core.asset.annotation.Render;
import com.conquestrefabricated.core.asset.annotation.State;
import com.conquestrefabricated.core.block.builder.Props;
import com.conquestrefabricated.core.util.RenderLayer;

@Assets(
        state = @State(name = "%s_slab", template = "parent_slab_overlay_top"),
        item = @Model(name = "item/%s_slab", parent = "block/%s_slab_bottom_4", template = "item/acacia_slab"),
        render = @Render(RenderLayer.CUTOUT_MIPPED_SOLID),
        block = {
                @Model(name = "block/%s_slab_bottom_1", template = "block/parent_slab_bottom_1_overlay_top"),
                @Model(name = "block/%s_slab_bottom_2", template = "block/parent_slab_bottom_2_overlay_top"),
                @Model(name = "block/%s_slab_bottom_3", template = "block/parent_slab_bottom_3_overlay_top"),
                @Model(name = "block/%s_slab_bottom_4", template = "block/parent_slab_bottom_4_overlay_top"),
                @Model(name = "block/%s_slab_bottom_5", template = "block/parent_slab_bottom_5_overlay_top"),
                @Model(name = "block/%s_slab_bottom_6", template = "block/parent_slab_bottom_6_overlay_top"),
                @Model(name = "block/%s_slab_bottom_7", template = "block/parent_slab_bottom_7_overlay_top"),
                @Model(name = "block/%s_slab_top_1", template = "block/parent_slab_top_1_overlay_top"),
                @Model(name = "block/%s_slab_top_2", template = "block/parent_slab_top_2_overlay_top"),
                @Model(name = "block/%s_slab_top_3", template = "block/parent_slab_top_3_overlay_top"),
                @Model(name = "block/%s_slab_top_4", template = "block/parent_slab_top_4_overlay_top"),
                @Model(name = "block/%s_slab_top_5", template = "block/parent_slab_top_5_overlay_top"),
                @Model(name = "block/%s_slab_top_6", template = "block/parent_slab_top_6_overlay_top"),
                @Model(name = "block/%s_slab_top_7", template = "block/parent_slab_top_7_overlay_top"),
                @Model(name = "block/%s", template = "block/parent_cube")
        }
)
public class TopOverlaySlab extends Slab {


    public TopOverlaySlab(Props props) {
        super(props);
    }
}