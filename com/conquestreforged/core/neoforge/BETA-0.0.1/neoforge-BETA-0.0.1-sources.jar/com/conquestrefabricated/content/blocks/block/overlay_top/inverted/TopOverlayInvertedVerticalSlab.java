package com.conquestrefabricated.content.blocks.block.overlay_top.inverted;

import com.conquestrefabricated.content.blocks.block.VerticalSlabExtendable;
import com.conquestrefabricated.core.asset.annotation.Assets;
import com.conquestrefabricated.core.asset.annotation.Model;
import com.conquestrefabricated.core.asset.annotation.Render;
import com.conquestrefabricated.core.asset.annotation.State;
import com.conquestrefabricated.core.block.builder.Props;
import com.conquestrefabricated.core.util.RenderLayer;

@Assets(
        state = @State(name = "%s_vertical_slab", template = "parent_vertical_slab_overlay_top_inverted"),
        item = @Model(name = "item/%s_vertical_slab", parent = "block/%s_vertical_slab_4", template = "item/parent_vertical_slab_tudor"),
        render = @Render(RenderLayer.CUTOUT_MIPPED_SOLID),
        block = {
                @Model(name = "block/%s_vertical_slab_1", template = "block/parent_vertical_slab_1_overlay_top_inverted"),
                @Model(name = "block/%s_vertical_slab_2", template = "block/parent_vertical_slab_2_overlay_top_inverted"),
                @Model(name = "block/%s_vertical_slab_4", template = "block/parent_vertical_slab_4_overlay_top_inverted"),
                @Model(name = "block/%s_vertical_slab_6", template = "block/parent_vertical_slab_6_overlay_top_inverted"),
        }
)
public class TopOverlayInvertedVerticalSlab extends VerticalSlabExtendable {

    public TopOverlayInvertedVerticalSlab(Props properties) {
        super(properties);
    }
}
